/*
  libheif example application.

  MIT License

  Copyright (c) 2017 struktur AG, Joachim Bauch <bauch@struktur.de>
  Copyright (c) 2023 Dirk Farin <dirk.farin@gmail.com>

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  SOFTWARE.
*/
#ifndef EXAMPLE_ENCODER_WEBP_H
#define EXAMPLE_ENCODER_WEBP_H

#include <string>

#include "encoder.h"

class WebPEncoder : public Encoder
{
public:
  WebPEncoder(int quality);

  heif_colorspace colorspace(bool has_alpha) const override
  {
    return quality_ == 100 ? heif_colorspace_RGB : heif_colorspace_YCbCr;
  }

  heif_chroma chroma(bool has_alpha, int bit_depth) const override
  {
    if (quality_ == 100) {
      return has_alpha ? heif_chroma_interleaved_RGBA : heif_chroma_interleaved_RGB;
    }
    return heif_chroma_420;
  }

  bool supports_alpha() const override { return true; }

  void UpdateDecodingOptions(const heif_image_handle* handle,
      heif_decoding_options* options) const override;

  bool Encode(const heif_image_handle* handle,
              const heif_image* image, const std::string& filename) override;

private:
  int quality_; // WebP quality, quality 100 = switch to lossless
};

#endif  // EXAMPLE_ENCODER_WEBP_H

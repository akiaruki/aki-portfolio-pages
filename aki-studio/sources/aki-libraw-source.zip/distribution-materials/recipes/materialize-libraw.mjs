// Reconstruct generated compiler inputs from the preserved upstream recipe.
// This script does not execute make, Docker, Emscripten or the upstream main().
import fs from 'node:fs/promises';
import vm from 'node:vm';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const recipeDir = path.dirname(fileURLToPath(import.meta.url));
const read = name => fs.readFile(path.join(recipeDir,'upstream',name),'utf8');
const [script,baseMakefile,capi] = await Promise.all([read('libraw-build.mjs'),read('LibRaw-Makefile.dist'),read('LibRaw-libraw_c_api.cpp')]);
const customStart=script.indexOf('const customFunctions =');
const customEnd=script.indexOf('async function main()');
const customFunctions=vm.runInNewContext(script.slice(customStart,customEnd)+'\ncustomFunctions;', {}, {timeout:1000});
const makeStart=script.indexOf('const patchedMakefile =');
const makeEnd=script.indexOf('const makefilePath =');
const makefile=vm.runInNewContext(script.slice(makeStart,makeEnd)+'\nmakefile;', {baseMakefile,customFunctions}, {timeout:1000});
const out=path.join(recipeDir,'generated','LibRaw');
await fs.mkdir(out,{recursive:true});
await fs.writeFile(path.join(out,'Makefile'),makefile);
await fs.writeFile(path.join(out,'libraw_c_api.cpp'),capi+Object.values(customFunctions).join('\n'));
console.log('Materialized exact upstream WASM modification recipe; no compiler was run.');

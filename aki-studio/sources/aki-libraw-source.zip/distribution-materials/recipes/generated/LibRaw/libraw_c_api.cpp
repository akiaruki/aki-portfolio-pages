/* -*- C++ -*-
 * File: libraw_c_api.cpp
 * Copyright 2008-2025 LibRaw LLC (info@libraw.org)
 * Created: Sat Mar  8 , 2008
 *
 * LibRaw C interface


LibRaw is free software; you can redistribute it and/or modify
it under the terms of the one of two licenses as you choose:

1. GNU LESSER GENERAL PUBLIC LICENSE version 2.1
   (See file LICENSE.LGPL provided in LibRaw distribution archive for details).

2. COMMON DEVELOPMENT AND DISTRIBUTION LICENSE (CDDL) Version 1.0
   (See file LICENSE.CDDL provided in LibRaw distribution archive for details).

 */

#include <math.h>
#include <errno.h>
#include "libraw/libraw.h"

#ifdef __cplusplus
#include <new>
extern "C"
{
#endif

  libraw_data_t *libraw_init(unsigned int flags)
  {
    LibRaw *ret;
    try
    {
      ret = new LibRaw(flags);
    }
    catch (const std::bad_alloc& )
    {
      return NULL;
    }
    return &(ret->imgdata);
  }

  unsigned libraw_capabilities() { return LibRaw::capabilities(); }
  const char *libraw_version() { return LibRaw::version(); }
  const char *libraw_strprogress(enum LibRaw_progress p)
  {
    return LibRaw::strprogress(p);
  }
  int libraw_versionNumber() { return LibRaw::versionNumber(); }
  const char **libraw_cameraList() { return LibRaw::cameraList(); }
  int libraw_cameraCount() { return LibRaw::cameraCount(); }
  const char *libraw_unpack_function_name(libraw_data_t *lr)
  {
    if (!lr)
      return "NULL parameter passed";
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->unpack_function_name();
  }

  void libraw_subtract_black(libraw_data_t *lr)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->subtract_black();
  }

  int libraw_open_file(libraw_data_t *lr, const char *file)
  {
    if (!lr)
      return EINVAL;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->open_file(file);
  }

  libraw_iparams_t *libraw_get_iparams(libraw_data_t *lr)
  {
    if (!lr)
      return NULL;
    return &(lr->idata);
  }

  libraw_lensinfo_t *libraw_get_lensinfo(libraw_data_t *lr)
  {
    if (!lr)
      return NULL;
    return &(lr->lens);
  }

  libraw_imgother_t *libraw_get_imgother(libraw_data_t *lr)
  {
    if (!lr)
      return NULL;
    return &(lr->other);
  }

#ifndef LIBRAW_NO_IOSTREAMS_DATASTREAM
  int libraw_open_file_ex(libraw_data_t *lr, const char *file, INT64 sz)
  {
    if (!lr)
      return EINVAL;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->open_file(file, sz);
  }
#endif

#ifdef LIBRAW_WIN32_UNICODEPATHS
  int libraw_open_wfile(libraw_data_t *lr, const wchar_t *file)
  {
    if (!lr)
      return EINVAL;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->open_file(file);
  }

#ifndef LIBRAW_NO_IOSTREAMS_DATASTREAM
  int libraw_open_wfile_ex(libraw_data_t *lr, const wchar_t *file, INT64 sz)
  {
    if (!lr)
      return EINVAL;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->open_file(file, sz);
  }
#endif
#endif
  int libraw_open_buffer(libraw_data_t *lr, const void *buffer, size_t size)
  {
    if (!lr)
      return EINVAL;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->open_buffer(buffer, size);
  }
  int libraw_open_bayer(libraw_data_t *lr, unsigned char *data,
                        unsigned datalen, ushort _raw_width, ushort _raw_height,
                        ushort _left_margin, ushort _top_margin,
                        ushort _right_margin, ushort _bottom_margin,
                        unsigned char procflags, unsigned char bayer_pattern,
                        unsigned unused_bits, unsigned otherflags,
                        unsigned black_level)
  {
    if (!lr)
      return EINVAL;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->open_bayer(data, datalen, _raw_width, _raw_height, _left_margin,
                          _top_margin, _right_margin, _bottom_margin, procflags,
                          bayer_pattern, unused_bits, otherflags, black_level);
  }
  int libraw_unpack(libraw_data_t *lr)
  {
    if (!lr)
      return EINVAL;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->unpack();
  }
  int libraw_unpack_thumb(libraw_data_t *lr)
  {
    if (!lr)
      return EINVAL;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->unpack_thumb();
  }
  int libraw_unpack_thumb_ex(libraw_data_t *lr, int i)
  {
    if (!lr)
      return EINVAL;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->unpack_thumb_ex(i);
  }
  void libraw_recycle_datastream(libraw_data_t *lr)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->recycle_datastream();
  }
  void libraw_recycle(libraw_data_t *lr)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->recycle();
  }
  void libraw_close(libraw_data_t *lr)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    delete ip;
  }

  void libraw_set_exifparser_handler(libraw_data_t *lr, exif_parser_callback cb,
                                     void *data)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->set_exifparser_handler(cb, data);
  }

  void libraw_set_makernotes_handler(libraw_data_t *lr, exif_parser_callback cb,
                                     void *data)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->set_makernotes_handler(cb, data);
  }

  void libraw_set_dataerror_handler(libraw_data_t *lr, data_callback func,
                                    void *data)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->set_dataerror_handler(func, data);
  }
  void libraw_set_progress_handler(libraw_data_t *lr, progress_callback cb,
                                   void *data)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->set_progress_handler(cb, data);
  }

  int libraw_adjust_to_raw_inset_crop(libraw_data_t *lr, unsigned mask, float maxcrop)
  {
    if (!lr)
      return EINVAL;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->adjust_to_raw_inset_crop(mask,maxcrop);
  }

  // DCRAW
  int libraw_adjust_sizes_info_only(libraw_data_t *lr)
  {
    if (!lr)
      return EINVAL;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->adjust_sizes_info_only();
  }
  int libraw_dcraw_ppm_tiff_writer(libraw_data_t *lr, const char *filename)
  {
    if (!lr)
      return EINVAL;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->dcraw_ppm_tiff_writer(filename);
  }
  int libraw_dcraw_thumb_writer(libraw_data_t *lr, const char *fname)
  {
    if (!lr)
      return EINVAL;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->dcraw_thumb_writer(fname);
  }
  int libraw_dcraw_process(libraw_data_t *lr)
  {
    if (!lr)
      return EINVAL;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->dcraw_process();
  }
  libraw_processed_image_t *libraw_dcraw_make_mem_image(libraw_data_t *lr,
                                                        int *errc)
  {
    if (!lr)
    {
      if (errc)
        *errc = EINVAL;
      return NULL;
    }
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->dcraw_make_mem_image(errc);
  }
  libraw_processed_image_t *libraw_dcraw_make_mem_thumb(libraw_data_t *lr,
                                                        int *errc)
  {
    if (!lr)
    {
      if (errc)
        *errc = EINVAL;
      return NULL;
    }
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->dcraw_make_mem_thumb(errc);
  }

  void libraw_dcraw_clear_mem(libraw_processed_image_t *p)
  {
    LibRaw::dcraw_clear_mem(p);
  }

  int libraw_raw2image(libraw_data_t *lr)
  {
    if (!lr)
      return EINVAL;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->raw2image();
  }
  void libraw_free_image(libraw_data_t *lr)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->free_image();
  }
  int libraw_get_decoder_info(libraw_data_t *lr, libraw_decoder_info_t *d)
  {
    if (!lr || !d)
      return EINVAL;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->get_decoder_info(d);
  }
  int libraw_COLOR(libraw_data_t *lr, int row, int col)
  {
    if (!lr)
      return EINVAL;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    return ip->COLOR(row, col);
  }

  /* getters/setters used by 3DLut Creator */
  DllDef void libraw_set_demosaic(libraw_data_t *lr, int value)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->imgdata.params.user_qual = value;
  }

  DllDef void libraw_set_output_color(libraw_data_t *lr, int value)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->imgdata.params.output_color = value;
  }

  DllDef void libraw_set_adjust_maximum_thr(libraw_data_t *lr, float value)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->imgdata.params.adjust_maximum_thr = value;
  }

  DllDef void libraw_set_output_bps(libraw_data_t *lr, int value)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->imgdata.params.output_bps = value;
  }

  	DllDef void libraw_set_output_tif(libraw_data_t *lr, int value)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->imgdata.params.output_tiff = value;
  }

#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define LIM(x, min, max) MAX(min, MIN(x, max))

  DllDef void libraw_set_user_mul(libraw_data_t *lr, int index, float val)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->imgdata.params.user_mul[LIM(index, 0, 3)] = val;
  }

  DllDef void libraw_set_gamma(libraw_data_t *lr, int index, float value)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->imgdata.params.gamm[LIM(index, 0, 5)] = value;
  }

  DllDef void libraw_set_no_auto_bright(libraw_data_t *lr, int value)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->imgdata.params.no_auto_bright = value;
  }

  DllDef void libraw_set_bright(libraw_data_t *lr, float value)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->imgdata.params.bright = value;
  }

  DllDef void libraw_set_highlight(libraw_data_t *lr, int value)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->imgdata.params.highlight = value;
  }

  DllDef void libraw_set_fbdd_noiserd(libraw_data_t *lr, int value)
  {
    if (!lr)
      return;
    LibRaw *ip = (LibRaw *)lr->parent_class;
    ip->imgdata.params.fbdd_noiserd = value;
  }

  DllDef int libraw_get_raw_height(libraw_data_t *lr)
  {
    if (!lr)
      return EINVAL;
    return lr->sizes.raw_height;
  }

  DllDef int libraw_get_raw_width(libraw_data_t *lr)
  {
    if (!lr)
      return EINVAL;
    return lr->sizes.raw_width;
  }

  DllDef int libraw_get_iheight(libraw_data_t *lr)
  {
    if (!lr)
      return EINVAL;
    return lr->sizes.iheight;
  }

  DllDef int libraw_get_iwidth(libraw_data_t *lr)
  {
    if (!lr)
      return EINVAL;
    return lr->sizes.iwidth;
  }

  DllDef float libraw_get_cam_mul(libraw_data_t *lr, int index)
  {
    if (!lr)
      return EINVAL;
    return lr->color.cam_mul[LIM(index, 0, 3)];
  }

  DllDef float libraw_get_pre_mul(libraw_data_t *lr, int index)
  {
    if (!lr)
      return EINVAL;
    return lr->color.pre_mul[LIM(index, 0, 3)];
  }

  DllDef float libraw_get_rgb_cam(libraw_data_t *lr, int index1, int index2)
  {
    if (!lr)
      return EINVAL;
    return lr->color.rgb_cam[LIM(index1, 0, 2)][LIM(index2, 0, 3)];
  }

  DllDef int libraw_get_color_maximum(libraw_data_t *lr)
  {
    if (!lr)
      return EINVAL;
    return lr->color.maximum;
  }

#ifdef __cplusplus
}
#endif

extern "C" DllDef ushort *libraw_get_raw_image(libraw_data_t *lr) {
	if (!lr) return NULL;
	return lr->rawdata.raw_image;
}
extern "C" DllDef libraw_thumbnail_t *libraw_get_thumbnail(libraw_data_t *lr) {
	if (!lr) return NULL;
	return &(lr->thumbnail);
}
extern "C" DllDef libraw_shootinginfo_t *libraw_get_shootinginfo(libraw_data_t *lr) {
	if (!lr) return NULL;
	return &(lr->shootinginfo);
}
extern "C" DllDef libraw_makernotes_t *libraw_get_makernotes(libraw_data_t *lr) {
	if (!lr) return NULL;
	return &(lr->makernotes);
}
extern "C" DllDef libraw_canon_makernotes_t *libraw_get_canon_makernotes(libraw_data_t *lr) {
	if (!lr) return NULL;
	return &(lr->makernotes.canon);
}
extern "C" DllDef libraw_nikon_makernotes_t *libraw_get_nikon_makernotes(libraw_data_t *lr) {
	if (!lr) return NULL;
	return &(lr->makernotes.nikon);
}
extern "C" DllDef libraw_hasselblad_makernotes_t *libraw_get_hasselblad_makernotes(libraw_data_t *lr) {
	if (!lr) return NULL;
	return &(lr->makernotes.hasselblad);
}
extern "C" DllDef libraw_fuji_info_t *libraw_get_fuji_info(libraw_data_t *lr) {
	if (!lr) return NULL;
	return &(lr->makernotes.fuji);
}
extern "C" DllDef libraw_olympus_makernotes_t *libraw_get_olympus_makernotes(libraw_data_t *lr) {
	if (!lr) return NULL;
	return &(lr->makernotes.olympus);
}
extern "C" DllDef libraw_sony_info_t *libraw_get_sony_info(libraw_data_t *lr) {
	if (!lr) return NULL;
	return &(lr->makernotes.sony);
}
extern "C" DllDef libraw_kodak_makernotes_t *libraw_get_kodak_makernotes(libraw_data_t *lr) {
	if (!lr) return NULL;
	return &(lr->makernotes.kodak);
}
extern "C" DllDef libraw_panasonic_makernotes_t *libraw_get_panasonic_makernotes(libraw_data_t *lr) {
	if (!lr) return NULL;
	return &(lr->makernotes.panasonic);
}
extern "C" DllDef libraw_pentax_makernotes_t *libraw_get_pentax_makernotes(libraw_data_t *lr) {
	if (!lr) return NULL;
	return &(lr->makernotes.pentax);
}
extern "C" DllDef libraw_p1_makernotes_t *libraw_get_phaseone_makernotes(libraw_data_t *lr) {
	if (!lr) return NULL;
	return &(lr->makernotes.phaseone);
}
extern "C" DllDef libraw_ricoh_makernotes_t *libraw_get_ricoh_makernotes(libraw_data_t *lr) {
	if (!lr) return NULL;
	return &(lr->makernotes.ricoh);
}
extern "C" DllDef libraw_samsung_makernotes_t *libraw_get_samsung_makernotes(libraw_data_t *lr) {
	if (!lr) return NULL;
	return &(lr->makernotes.samsung);
}
extern "C" DllDef libraw_metadata_common_t *libraw_get_common_metadata(libraw_data_t *lr) {
	if (!lr) return NULL;
	return &(lr->makernotes.common);
}
extern "C" DllDef unsigned libraw_get_black(libraw_data_t *lr) {
	if (!lr) return 0;
	return lr->color.black;
}
extern "C" DllDef unsigned libraw_get_cblack(libraw_data_t *lr, int index) {
	if (!lr) return 0;
	if (index < 0 || index >= (int)LIBRAW_CBLACK_SIZE) return 0;
	return lr->color.cblack[index];
}
extern "C" DllDef unsigned libraw_get_data_maximum(libraw_data_t *lr) {
	if (!lr) return 0;
	return lr->color.data_maximum;
}
extern "C" DllDef float libraw_get_cam_xyz(libraw_data_t *lr, int i, int j) {
	if (!lr) return 0.0f;
	if (i < 0 || i >= 4 || j < 0 || j >= 3) return 0.0f;
	return lr->rawdata.color.cam_xyz[i][j];
}
extern "C" DllDef int libraw_get_active_height(libraw_data_t *lr) {
    if (!lr) return 0;
    return lr->sizes.height;
}
extern "C" DllDef int libraw_get_active_width(libraw_data_t *lr) {
    if (!lr) return 0;
    return lr->sizes.width;
}
static unsigned libraw_adjusted_black_level(libraw_data_t *lr, int index) {
    unsigned black = lr->rawdata.color.black;
    unsigned cblack[LIBRAW_CBLACK_SIZE];
    unsigned filters = lr->idata.filters;
    int c;
    int common;

    memcpy(cblack, lr->rawdata.color.cblack, sizeof(cblack));

    if (filters > 1000 && (cblack[4] + 1) / 2 == 1 &&
        (cblack[5] + 1) / 2 == 1) {
        LibRaw *libraw = (LibRaw *)lr->parent_class;
        int colors[4];
        int green_count = 0;
        int last_green = -1;

        for (c = 0; c < 4; c++) {
            colors[c] = libraw->FC(c / 2, c % 2);
            if (colors[c] == 1) {
                green_count++;
                last_green = c;
            }
        }
        if (green_count > 1 && last_green >= 0) colors[last_green] = 3;
        for (c = 0; c < 4; c++) {
            cblack[colors[c]] +=
                cblack[6 + c / 2 % cblack[4] * cblack[5] + c % 2 % cblack[5]];
        }
        cblack[4] = cblack[5] = 0;
    } else if (filters <= 1000 && cblack[4] == 1 && cblack[5] == 1) {
        for (c = 0; c < 4; c++) cblack[c] += cblack[6];
        cblack[4] = cblack[5] = 0;
    }

    common = cblack[3];
    for (c = 0; c < 3; c++) {
        if (common > (int)cblack[c]) common = cblack[c];
    }
    for (c = 0; c < 4; c++) cblack[c] -= common;
    black += common;

    if (cblack[4] && cblack[5]) {
        int nonzero = 0;

        common = cblack[6];
        for (c = 1; c < (int)(cblack[4] * cblack[5]); c++) {
            if (common > (int)cblack[6 + c]) common = cblack[6 + c];
        }
        for (c = 0; c < (int)(cblack[4] * cblack[5]); c++) {
            cblack[6 + c] -= common;
            if (cblack[6 + c]) nonzero++;
        }
        black += common;
        if (!nonzero) cblack[4] = cblack[5] = 0;
    }

    return cblack[index] + black;
}

extern "C" DllDef unsigned libraw_get_black_level(libraw_data_t *lr, int index) {
    if (!lr || index < 0 || index >= 4) return 0;
    return libraw_adjusted_black_level(lr, index);
}
extern "C" DllDef int libraw_get_bottom_margin(libraw_data_t *lr) {
    if (!lr) return 0;
    return lr->sizes.raw_height - lr->sizes.height - lr->sizes.top_margin;
}
extern "C" DllDef int libraw_get_cdesc(libraw_data_t *lr, int index) {
    if (!lr || index < 0 || index >= 5) return 0;
    return (unsigned char)lr->idata.cdesc[index];
}
extern "C" DllDef float libraw_get_cmatrix(libraw_data_t *lr, int i, int j) {
    if (!lr || i < 0 || i >= 3 || j < 0 || j >= 4) return 0.0f;
    return lr->rawdata.color.cmatrix[i][j];
}
extern "C" DllDef ushort *libraw_get_color3_image(libraw_data_t *lr) {
    if (!lr) return NULL;
    return (ushort *)lr->rawdata.color3_image;
}
extern "C" DllDef ushort *libraw_get_color4_image(libraw_data_t *lr) {
    if (!lr) return NULL;
    return (ushort *)lr->rawdata.color4_image;
}
extern "C" DllDef int libraw_get_colors(libraw_data_t *lr) {
    if (!lr) return 0;
    return lr->idata.colors;
}
extern "C" DllDef unsigned libraw_get_filters(libraw_data_t *lr) {
    if (!lr) return 0;
    return lr->idata.filters;
}
extern "C" DllDef int libraw_get_flip(libraw_data_t *lr) {
    if (!lr) return 0;
    return lr->sizes.flip;
}
extern "C" DllDef unsigned libraw_get_is_foveon(libraw_data_t *lr) {
    if (!lr) return 0;
    return lr->idata.is_foveon;
}
extern "C" DllDef int libraw_get_left_margin(libraw_data_t *lr) {
    if (!lr) return 0;
    return lr->sizes.left_margin;
}
extern "C" DllDef unsigned libraw_get_linear_max(libraw_data_t *lr, int index) {
    if (!lr || index < 0 || index >= 4) return 0;
    return lr->rawdata.color.linear_max[index];
}
extern "C" DllDef double libraw_get_pixel_aspect(libraw_data_t *lr) {
    if (!lr) return 0.0;
    return lr->sizes.pixel_aspect;
}
extern "C" DllDef unsigned libraw_get_raw_pitch(libraw_data_t *lr) {
    if (!lr) return 0;
    return lr->sizes.raw_pitch;
}
extern "C" DllDef int libraw_get_right_margin(libraw_data_t *lr) {
    if (!lr) return 0;
    return lr->sizes.raw_width - lr->sizes.width - lr->sizes.left_margin;
}
extern "C" DllDef int libraw_get_top_margin(libraw_data_t *lr) {
    if (!lr) return 0;
    return lr->sizes.top_margin;
}
extern "C" DllDef void libraw_set_half_size(libraw_data_t *lr, int value) {
	if (!lr) return;
	lr->params.half_size = value;
}
extern "C" DllDef void libraw_set_use_camera_wb(libraw_data_t *lr, int value) {
	if (!lr) return;
	lr->params.use_camera_wb = value;
}
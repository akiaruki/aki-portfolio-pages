# Third-party decoder build recipes

These are preserved public recipes. They have not been run locally; the Windows environment has no Emscripten or Docker command. Tool versions are inferred from these exact upstream files. An original compiler log or a successful rebuild comparison remains necessary to prove the shipped compiler/runtime provenance.

## LibRaw

Use `colorhythm/libraw-wasm` commit `9b0f59a5e0f6d3d12a8f6fa594015ef4f30a6e95` with `packages/libraw.wasm/LibRaw` populated from `LibRaw/LibRaw` commit `b860248a89d9082b8e0a1e202e516f46af9adb29`. Do not fetch the unrelated raw-samples submodule or samples. Source archives omit git submodule content, so explicitly populate this directory before building.

The original Dockerfile uses `emscripten/emsdk:4.0.15-arm64`, then installs `libclang-dev`; the image digest and apt package versions are not pinned. Preserve a digest and package inventory in the eventual rebuild. A Linux ARM64 Docker runner matches the declared image; do not silently substitute a compiler revision.

From `packages/libraw.wasm`, `docker compose run --build builder` executes `node /src/scripts/build.mjs`. That script derives `LibRaw/Makefile` from `Makefile.dist`, substitutes emcc/em++, disables zlib flags, adds `USE_X3FTOOLS` and exceptions, appends exported C accessors to `src/libraw_c_api.cpp`, builds, restores the C API source, and moves `libraw.mjs`/`libraw.wasm` to `dist`. Preserve the script as the authoritative modification recipe and record the patched compilation inputs before the script restores them.

For wrapper TypeScript/bindings, use the repository's package manager and lockfile, `packages/libraw.wasm/package.json`, `scripts/bindings.mjs`, `tsconfig.json` and generated type source. Read the exact scripts before running the wrapper's complete build; `build` runs WASM, bindings and TypeScript. Its compose `bindgen` service uses `@typed-cstruct/generator@0.5.0` and the LibRaw headers. Do not assume it is a dependency-free standalone build.

App packaging renames `libraw.mjs` to `runtime.js`, changes `./libraw.mjs` imports to `./runtime.js`, and rewrites `typed-cstruct` imports to `./typed-cstruct/index.js` in `index.js`/`libraw-types.js`. The WASM binary itself is copied without transformation. MIT notices accompany the wrapper and typed-cstruct. No app-private code is part of this public source recipe.

## libheif/libde265/libheif-js

Populate `catdad-experiments/libheif-emscripten` commit `dd5a19b878149437a5a427f6e1afa8bac624a714` (v1.23.2) `libheif` submodule from `strukturag/libheif` commit `ac1cb05c39008f01525c991ff8b88f84ddf70fd2`.

Follow `.github/workflows/emscripten.yml`, WASM branch, on Ubuntu 22.04: Node24, global TypeScript5, `EMSCRIPTEN_VERSION=3.1.61`, then `libheif/scripts/install-ci-linux.sh`, `prepare-ci.sh`. The workflow produces `scripts/run-ci-wasm.sh` by replacing `USE_WASM=0` with `USE_WASM=1 USE_UNSAFE_EVAL=0` and `USE_TYPESCRIPT=0` with `USE_TYPESCRIPT=1`; execute that transformed script, then run the distribution repository's `dist-prep.sh wasm`. Store the transformed script and complete version/build log. Node24/TypeScript5 and other CI packages are floating major versions; historic exact toolchain versions have not been reconstructed.

Pinned `libheif/build-emscripten.sh` enables libde265 1.0.15 by default, AOM/WebCodecs/OpenJPEG/uncompressed disabled. It downloads the upstream release `libde265-1.0.15.tar.gz`; preserve that exact release archive, not only the source tag. It builds libde265 static with `--disable-shared --disable-sse --disable-dec265 --disable-sherlock265`; C++ `-O3`. It builds libheif static, no plugin loading, examples, GDK pixbuf or multithreading; final `emcc` link uses whole-archive libheif, `-lde265`, embind, modularize, growth and no async WASM compilation. The bundling scripts and configuration are preserved in source, including `post.js`.

Use `catdad-experiments/libheif-js` commit `6ca00b818c0ff51cb2a5c75b9ce97d708083335a`. Its `scripts/install.js` accepts an explicit local `libheif.tar.gz`, minifies/transforms generated JavaScript to ES2019, then bundles WASM with esbuild and empty fs/path polyfills. Use its pinned lockfile where present; package.json alone uses dependency ranges. The final ESM `libheif-wasm/libheif-bundle.mjs` is copied to app `vendor/heif/decoder.js` unchanged. Do not run photo fixture/test download scripts to prepare redistributable source.

## Acceptance for a real corresponding-source claim

Rebuild the exact sources and compare original generated decoder bytes or explain reproducible-build differences; enumerate archive/runtime licenses, compiler contributions and disabled/linked codecs from the actual link output. Retain generated modified LibRaw sources and patched HEIF CI script. Test replacement against the app's decoder API with the original and an interface-compatible modified decoder. Source completeness does not depend on a bit-identical rebuild, but exact version and all modifications do need evidence. This bundle is not presently a relink/installation package for the full signed app.

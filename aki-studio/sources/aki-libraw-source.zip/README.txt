Aki Studio third-party source and build materials.
Public upstream source and documented binding/build modifications only.
No private application source, signing data, photographs or prebuilt decoder binaries.
Build recipes identify expected compiler versions; original compiler logs and a verified rebuild are unavailable.
This source archive is not a full application relink/installation package or a legal certification.
See distribution-materials/recipes/BUILD-RECIPES.md and preserved component licenses.
